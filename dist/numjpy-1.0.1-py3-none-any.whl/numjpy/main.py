def main(number):
    return number + 2

if __name__ =="__main__":
    print(main(number=3))